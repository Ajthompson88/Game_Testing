import { IQuestion, Question } from './Question.js';

export { IQuestion, Question };
